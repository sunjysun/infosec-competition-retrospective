<?php
return [
    'app\home\command\UnfreezeMoney',
    'app\home\command\AutoCash',
    'app\home\command\Migrate',
    'app\home\command\Migrate20180510',
    'app\home\command\AutoEmptyGoodsTrash',
    'app\home\command\AutoClearExpireOrder',
];
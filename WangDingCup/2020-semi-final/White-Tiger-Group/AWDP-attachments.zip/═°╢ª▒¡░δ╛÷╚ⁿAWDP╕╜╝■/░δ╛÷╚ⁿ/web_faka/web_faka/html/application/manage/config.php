<?php
return [
		"development" => 0, //开发模式，暂用于更改后台支付接口参数
		];